//window.onload = function() {
//	var speed = 30
//	img2.innerHTML = img2.innerHTML
//	var mymar=setInterval(marquee,speed)
//		sliderWrap.onmouseover=function() {clearInterval(mymar)}
//		sliderWrap.onmouseout=function() {MyMar3=setInterval(marquee,speed)}
//}
//
//function marquee(){
//	if(img2.offsetWidth-sliderWrap.scrollLeft<=0)
//		sliderWrap.scrollLeft-=img1.offsetWidth
//		else{
//		sliderWrap.scrollLeft++
//		}
//}

function showBGcolor(){
	//event.srcElement.tagName ;
//	alert(event.srcElement.tagName)
	if(event.srcElement && event.srcElement.tagName=="A"){
		var atag = event.srcElement;
		atag.style.backgroundColor = "#0c8ed9" ;
	}
}

function clearBGcolor(){
	if(event.srcElement && event.srcElement.tagName =="A"){
		var atag = event.srcElement;
		atag.style.backgroundColor = "Transparent" ;
	}
}


