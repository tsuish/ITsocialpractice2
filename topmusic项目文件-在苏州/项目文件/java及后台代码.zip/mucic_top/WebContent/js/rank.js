rankShowColor = function (){
	if(event.srcElement && event.srcElement.tagName=="A")
	{
		var a = event.srcElement;
		a.style.backgroundColor = "lightskyblue";
		a.style.color = "#fff";
	}
}

rankClearColor = function(){
	if(event.srcElement && event.srcElement.tagName=="A")
	{
		var a = event.srcElement;
		a.style.backgroundColor = "Transparent";
		a.style.color = "#555";
	}
}

rankMainShowColor = function (){
	if(event.srcElement && event.srcElement.tagName=="A")
	{
		var a = event.srcElement;
		a.style.backgroundColor = "#169af3";
		a.style.color = "#fff";
	}
}

rankMainClearColor = function(){
	if(event.srcElement && event.srcElement.tagName=="A")
	{
		var a = event.srcElement;
		a.style.backgroundColor = "#169af3";
		a.style.color = "#fff";
	}
}
