package zzti.music_top.pojo;

public class Music {
		
		private int id ;                		  //song_id          ������ʶ
		private String name;      		 //song_name     ��������
		private String singer;   	 	    //song_singer         ����
		private String link;     	       //song_link          ��������
		private String duration;      //song_duration       ʱ��
		private String type;            //song_type           ������
		
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSInger() {
			return singer;
		}

		public void setSInger(String singer) {
			this.singer = singer;
		}
		
		public String getLink() {
			return link;
		}

		public void setLink(String link) {
			this.link = link;
		}

		public String getSinger() {
			return singer;
		}

		public void setSinger(String singer) {
			this.singer = singer;
		}

		public String getDuration() {
			return duration;
		}

		public void setDuration(String duration) {
			this.duration = duration;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public Music(){
			
		}
		
		public Music(String name, String singer, String link,
				String duration) {
			super();
			this.name = name;
			this.singer = singer;
			this.link = link;
			this.duration = duration;
		}
	}
