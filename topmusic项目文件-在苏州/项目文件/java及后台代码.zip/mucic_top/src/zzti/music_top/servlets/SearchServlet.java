package zzti.music_top.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zzti.music_top.dao.MusicDAO;
import zzti.music_top.dao.factory.MusicDAOFactory;
import zzti.music_top.pojo.Music;

/**
 * Servlet implementation class TOPNServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//          http://localhost:8080/mucic_top/SearchServlet.do?flag=TOPN
		
		//           http://localhost:8080/mucic_top/main2.jsp
		
		request.setCharacterEncoding("UTF-8");
		MusicDAO musicDao = MusicDAOFactory.getMusicDAOInstance();
		//����flag����ȷҪ��ѯ�İ�
		String flagOriginal = musicDao.analysis(request.getParameter("flag"));
		String [] str=flagOriginal.split(" ");
		String flag = str[0];
		//ִ�в�ѯ����
		List<Music> musicListtransmit = new ArrayList<Music>();
		List<Music> musicList = musicDao.getMusicList(flag);
		
		//��ȡid��count����ȷҪ��ʾ������
		int id = 0;
		int count = musicList.size();
		String idOriginal = request.getParameter("id");
		if(idOriginal != null&&!idOriginal.equals("")){
			id = Integer.valueOf(idOriginal).intValue();
		}
		if(id == 0){
			
				if(count<=20){
					musicListtransmit.addAll(musicList.subList(0,count));
				}else{
					musicListtransmit.addAll(musicList.subList(0,20));
				}
				
		}else{
				    musicListtransmit = musicDao.getList(count,musicList,id);
			}
		        //ȷ�����ӵ�URL
				String pathPart = str[1];
				String path = "rank_"+pathPart;
			    //�ض���jsp
				HttpSession session = request.getSession();
				session.setAttribute("musicList", musicListtransmit);
				response.sendRedirect(path);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
