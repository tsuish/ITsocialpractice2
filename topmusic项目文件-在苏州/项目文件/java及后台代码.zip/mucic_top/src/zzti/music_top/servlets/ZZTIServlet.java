package zzti.music_top.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zzti.music_top.dao.MusicDAO;
import zzti.music_top.dao.factory.MusicDAOFactory;
import zzti.music_top.pojo.Music;

/**
 * Servlet implementation class ZZTIServlet
 */
@WebServlet("/ZZTIServlet")
public class ZZTIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ZZTIServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		/**
		 * ��ÿ���񵥵�ǰ���׻�����ʾ
		 */
		
		MusicDAO musicDao = MusicDAOFactory.getMusicDAOInstance();
		List<Music> musicList = musicDao.getMusicFTList();
		HttpSession session = request.getSession();
		session.setAttribute("musicList", musicList);
		response.sendRedirect("rank.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
