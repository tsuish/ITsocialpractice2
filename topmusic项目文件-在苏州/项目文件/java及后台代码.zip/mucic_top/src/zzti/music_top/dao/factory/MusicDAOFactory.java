package zzti.music_top.dao.factory;

import zzti.music_top.dao.MusicDAO;
import zzti.music_top.dao.impl.MusicDAOImpl;

public class MusicDAOFactory {
	
	public static MusicDAO getMusicDAOInstance(){
		return MusicDAOImpl.getInstance();
	}

}
