package zzti.music_top.dao.base.dao;

import java.sql.ResultSet;
import java.util.List;
import zzti.music_top.pojo.Music;

@SuppressWarnings("rawtypes")
public class DefultMusicParseResultSet implements IParseResultSet{

	@Override
	public List<Music> parseRS(ResultSet rs) {
		// TODO Auto-generated method stub
		return null;
	}

}
