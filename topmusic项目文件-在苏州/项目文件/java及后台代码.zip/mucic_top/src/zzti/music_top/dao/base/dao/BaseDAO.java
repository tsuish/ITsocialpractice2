package zzti.music_top.dao.base.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BaseDAO<T> {

	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/musictop?useSSL=true&useUnicode=true&characterEncoding=UTF-8";
	private static final String USER = "root";
	private static final String PWD = "root";
	
	Connection conn = null;
	PreparedStatement prs = null;
	ResultSet rs = null;
	
	/**
	 * ��ȡ���Ӷ���
	 * @return Connection
	 */
	protected Connection getConnection() {
		try {
			Class.forName(DRIVER);
			return DriverManager.getConnection(URL,USER,PWD);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * �ر�����
	 * @param conn
	 * @param prs
	 * @param rs
	 */
	protected void close(ResultSet rs,PreparedStatement prs ,Connection conn ){
		try {
			if(rs != null){
				rs.close();
			}
			if(prs != null){
				prs.close();
			}
			if(conn != null && !conn.isClosed()){     //conn.isClosed()�жϵ�ǰ�����Ƿ񱻹ر�
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * ����ͬ���֣�ִ�в�ѯ����
	 * @param sql��sql���
	 * @param params��sql����
	 * @return List<T>
	 */
	protected List<T> executeQuery(IParseResultSet<T> parse, String sql , Object...params){ 
		conn = getConnection();            
		try {
			prs = conn.prepareStatement(sql);
		    setParams(prs, params);
			rs =  prs.executeQuery();
			//����rs����
			return parse.parseRS(rs);//���˲���ת�Ƶ�IParseResultSet<T>�ӿڵ�parseRS������
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			close( rs, prs, conn);
		}
		return null;
	}
	
	/**
	 * �򻯴��룬�������ͬ���벿�֣����ò���
	 * @param prs
	 * @param params
	 */
	private void setParams(PreparedStatement prs, Object...params){
			try {
				for(int i = 0;i<params.length;i++){
					prs.setObject(i+1, params[i]);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}
	
	/**
	 * ��ȡ0~9֮���������������߽�ֵ
	 * @return  List<Integer>
	 */
	public static List<Integer> getRandomNumber(){
	      List<Integer> list = new ArrayList<Integer>();
	      while(list.size()<10){
	    	  Integer randomNumber = (int) (Math.random()*10);//����0-10�����
	    	  if (!list.contains(randomNumber)) {//�ж��Ƿ��ظ��������ظ��ļ��뼯��
	              list.add(randomNumber);
	          }
	      }
	      return list;
	  }
	
}
