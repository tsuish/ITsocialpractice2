package zzti.music_top.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import zzti.music_top.dao.MusicDAO;
import zzti.music_top.dao.base.dao.BaseDAO;
import zzti.music_top.dao.base.dao.DefultMusicParseResultSet;
import zzti.music_top.pojo.Music;

public class MusicDAOImpl extends BaseDAO<Music> implements MusicDAO{
	
	//����ģʽ
	private MusicDAOImpl (){
	}
	private static MusicDAOImpl instance;
	public synchronized static MusicDAOImpl getInstance(){
		if(instance == null){
			instance = new MusicDAOImpl();
		}
		return instance;
	}
	
	/**
	 * ʹ���ڲ������rs�����
	 * @author ������
	 *
	 */
	class MusicParseResultSet extends DefultMusicParseResultSet{
		@Override
		public List<Music> parseRS(ResultSet rs) {
			// TODO Auto-generated method stub
			List<Music> musicList = new ArrayList<Music>();
			try {
				int i = 1;
				while(rs.next()){
					String name = rs.getString("song_name");
					String singer = rs.getString("song_singer");
					String link = rs.getString("song_link");
					String duration = rs.getString("song_duration");
					
					Music music = new Music(name,singer,link,duration);
					music.setId(i++);
					musicList.add(music);
				}
				return musicList;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}
	}
	
	/**
	 * ����flag
	 * @param flag
	 * @return  String
	 */
	public String analysis(String flag){
		if(flag.equals("TOPN") ){
			return "TOP new.jsp";
		}else if(flag.equals("NENR")){
        	return "���� inter.jsp";
		}
        else if(flag.equals("DJHT")){
        	return "DJ dj.jsp";
}
        else if(flag.equals("CHNW")){
        	return "���� cn.jsp";
}
        else if(flag.equals("EUSN")){
        	return "ŷ�� us.jsp";
}
        else if(flag.equals("KONE")){
        	return "���� ko.jsp";
		}	
        else if(flag.equals("JANE")){
        	return "�ձ� jp.jsp";
		}
        else if(flag.equals("TOCH")){
        	return "���� sun.jsp";
		}
        else if(flag.equals("GOVO")){
        	return "���� song.jsp";
		}
        else if(flag.equals("HISO")){
        	return "���� gold.jsp";
		}
		return null;
		
	}
	
	/**
	 * ��������֮��Ĺ�ϵ,������Ҫ��ʾ�ĸ�������
	 * @param count, list, id
	 * @return  List<Music>
	 */
	public List<Music> getList(int count,List<Music> list,int id){
		List<Music> musicListtransmit = new ArrayList<Music>();
		if(count<=20*(id-1)){
		        musicListtransmit = null;
         }
        else if(count>20*(id-1)&&count<=20*id){
 			musicListtransmit.addAll(list.subList(20*(id-1),count));
		 }else{
			 musicListtransmit.addAll(list.subList(20*(id-1),20*id));
		 }
		return musicListtransmit;
	}
	
	
	/**
	 * ����id˳���ȡ�ض��񵥵�������Ϣ
	 * @return List<music>
	 */
	@SuppressWarnings("unchecked")
	public List<Music> getMusicList(String flag){
		String sql = "select * from song where song_type like '%"+flag+"%' order by song_id;";
		return super.executeQuery(new MusicParseResultSet(), sql);
	}
	
	/**
	 * ��ȡ�ض�ÿ����ǰ�������ֵ���Ϣ
	 * @return List<music>
	 */
	@SuppressWarnings("unchecked")
	public List<Music> getMusicFTList(){
		List<Integer> listInt = getRandomNumber();
		String sql ="";
		String[] sqlValue = {"�ձ�","������","TOP","����","����","ŷ��","����","DJ","����","����"};
		for(int i = 0;i<9;i++){
			sql += "(select song_name,song_singer,song_duration,song_link from song where song_type like '%"+sqlValue[listInt.get(i)]+"%' order by song_id limit 2)union\n";
		}
		sql += "(select song_name,song_singer,song_duration,song_link from song where song_type like '%"+sqlValue[listInt.get(9)]+"%' order by song_id limit 2);";

		return super.executeQuery(new MusicParseResultSet(), sql);
	}
}
