package zzti.music_top.dao.base.dao;

import java.sql.ResultSet;
import java.util.List;

public interface IParseResultSet<T> {
	/**
	 * ����rs�����
	 * @param rs
	 * @return
	 */
	List<T> parseRS(ResultSet rs);
	
}
