import requests
from lxml import etree
from Python_KugouMusic.add_to_db import Add
class getdata():
    def __init__(self):
        pass

    #  避免重复的代码
    def get_help(self, urls):
        i = 0
        for url in urls:
            i = i + 1
            self.get_info(url, i)

    #  爬取 酷狗TOP500
    def get_TOPN(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-8888.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 网络红歌榜
    def get_NERE(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-23784.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 DJ热歌榜
    def get_DJHT(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-24971.html?from=rank'.format(str(i)) for i in range(1, page)]  # DJ热歌榜
        self.get_help(urls)

    #  爬取 华语新歌榜
    def get_CHNW(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-31308.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 欧美新歌榜
    def get_EUSN(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-31310.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 韩国新歌榜
    def get_KONE(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-31311.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 日本新歌榜
    def get_JANE(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-31312.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 明日之子第二季榜
    def get_TOCH(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-33240.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 2018中国好声音榜
    def get_GOVO(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-33366.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 金曲捞第二季榜
    def get_HISO(self, page):
        urls = ['http://www.kugou.com/yy/rank/home/{}-33419.html?from=rank'.format(str(i)) for i in range(1, page)]
        self.get_help(urls)

    #  爬取 所有歌榜
    def get_all(self, page):
        # 酷狗TOP500 TOPN
        self.get_TOPN(page)
        # 网络红歌榜 NERE
        self.get_NERE(page)
        # DJ热歌榜 DJHT
        self.get_DJHT(page)
        # 华语新歌榜 CHNW
        self.get_CHNW(page)
        # 欧美新歌榜 EUSN
        self.get_EUSN(page)
        # 韩国新歌榜 KONE
        self.get_KONE(page)
        # 日本新歌榜 JANE
        self.get_JANE(page)
        # 明日之子第二季榜 TOCH
        self.get_TOCH(page)
        # 2018中国好声音榜 GOVO
        self.get_GOVO(page)
        # 金曲捞第二季榜 HISO
        self.get_HISO(page)

    # 根据一条链接，从酷狗爬取数据，并存入数据库
    def get_info(self, url, i):
        ADD = Add()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Android 6.0; Nexus 5 Build/MRA58N)\
                AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Mobile Safari/537.36'}
        # get源码,encode,解析,xpath,保存
        response = requests.get(url, headers=headers)
        response_str = response.text.encode('utf-8')
        selector = etree.HTML(response_str)
        soup = selector.xpath('//*[@class="pc_temp_songlist "]//ul//li/a')

        if soup is not None and i == 1:
            song_type = soup[0].xpath('../../../../..//div//div/h3/text()')[0].strip()
            ADD.del_all(song_type)
            # print(len(soup))
        for j, sp in enumerate(soup):
            if j < 3 and i == 1:
                song_id = eval(sp.xpath('..//span/strong/text()')[0])
            else:
                song_id = eval(sp.xpath('..//span[@class="pc_temp_num"]/text()')[0].split()[0])
                if song_id > 100:
                    break
            # song_singer 歌手名字
            # song_name 歌曲名字
            #  song_link 歌曲链接
            #  song_duration 歌曲时长
            #  song_type  歌曲所在榜单
            song_str = sp.xpath('./text()')[0].split('-')
            if len(song_str) > 1:
                song_singer = song_str[0]
                song_name = song_str[1]
            else:
                continue
                # song_singer = ""
                # song_name = ""
            #     for i, song_one in enumerate(song_str):
            #         if i == 0:
            #             song_singer = song_one
            #         else:
            #             song_name = song_name + song_one
            song_link = sp.xpath('./@href')[0].strip()
            song_duration = sp.xpath('..//span/span/text()')[0].split()[0]
            song_type = sp.xpath('../../../../..//div//div/h3/text()')[0].strip()
            print(song_id, song_name, song_singer, song_link, song_duration, song_type)
            ADD.add(song_id , song_name, song_singer, song_link, song_duration, song_type,)
