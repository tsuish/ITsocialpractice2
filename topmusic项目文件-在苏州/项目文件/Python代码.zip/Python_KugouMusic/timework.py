import datetime
import time
from Python_KugouMusic.getdata import getdata
# 定时任务
now = datetime.datetime.now()
time_i = 20  # time_i  闹钟响铃间隔时间（秒）
time_wait = 5  # time_wait  定时滚动时间（秒）
sched_timer = now   # 闹钟响铃时间
# stop_time = now + datetime.timedelta(seconds=60)  # 闹钟终止时间
stop_time = datetime.datetime(2018, 8, 29, 15, 40, 10)
while (True):
    # 启动时间
    now = datetime.datetime.now()
    if sched_timer > now:
        print("程序运行中....", sched_timer-now, "秒后爬取数据")
        time.sleep(time_wait)
    else:
        getdata().get_all(6)
        print("现在时间：", datetime.datetime.now())
        print(sched_timer-datetime.datetime.now(), "秒后再爬取一次数据")
        print("程序终止时间：", stop_time)
        print("程序终止剩余时间：", stop_time-sched_timer)
        sched_timer = sched_timer + datetime.timedelta(seconds=time_i)
    if now > stop_time:
        break
print("已退出")

# 启动时间也可自行手动设置
# print(datetime.timedelta(seconds=5))
#sched_timer = datetime.datetime(2017,12,13,9,30,10)
# print(sched_timer)
