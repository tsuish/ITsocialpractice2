import pymysql
class Add():
    def __init__(self):
        pass

    def add(self, song_id, song_name, song_singer, song_link, song_duration, song_type):
        # 打开数据库连接
        db = self.get_conn()
        # 使用cursor()方法获取操作游标
        cursor = db.cursor()
        # SQL 插入语句
        sql = 'INSERT INTO SONG VALUES ("%d", "%s", "%s", "%s", "%s", "%s")' % (song_id, song_name, song_singer, song_link, song_duration, song_type)
        try:
            # 执行sql语句
            cursor.execute(sql)
            # 执行sql语句
            db.commit()
            print("insert ok")
        except:
            # 发生错误时回滚
            db.rollback()
            print("I'm roll backing")
        # 关闭数据库连接
        db.close()

    def get_conn(self):
        conn = pymysql.connect(host='127.0.0.1', port=3306, user="root", passwd="root", db="musictop", charset="utf8")
        return conn

    def is_empty(self):
        cursor = self.get_conn().cursor()
        sql='select * from song'
        rows = cursor.execute(sql)
        if rows > 0:
            return False
        else:
            return True

    def del_all(self, song_type):
        if self.is_empty():
            print("数据为空")
        else:
            sql = "delete from song where song_type='%s'" % (song_type)
            conn = self.get_conn()
            conn.cursor().execute(sql)
            conn.commit()
            print("已清空数据")
